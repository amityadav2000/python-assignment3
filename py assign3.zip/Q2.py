list1=[1,2,3,4,5]
print(list1)

list2=["a","b","c","d","e"]
print(list2)

d=dict(zip(list1,list2))
print(d)
