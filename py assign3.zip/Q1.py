import shutil
file1=input("enter name of  file1:")

file2=inpur("enter name of file2:")

destination=input("enter the destination file name:")

with open(destination,"wb") as wfd:
	
	for files in(file1,file2):
		
		with open(files,"rb") as fd:
			
			shutil.copyfileobj(fd,wfd)
			
chek=open(destination,"r")

print(chek.read())


chek.close()
		